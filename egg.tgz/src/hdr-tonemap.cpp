// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Tonemap HDR scene\n", stdout);
  return lionss_run_workload("hdr-tonemap");
}
