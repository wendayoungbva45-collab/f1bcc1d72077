// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Integrate with RK4"); }
int main(){
  announce();
  return lionss_run_workload("rk4_adaptive");
}
